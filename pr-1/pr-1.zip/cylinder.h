#pragma once

class Cylinder{
	public:
		double length;
		double diameter;
};
