#pragma once
#include <string>

class Coin {

    public:
    std::string denomination;
	double weight;
	double diameter;
	double thickness;
    double no_of_coins;
};
